import React, { useState } from 'react';
import { Vehicle } from '../types';
import { FileText, Download, Filter, Calendar, BarChart3, AlertTriangle, Clock } from 'lucide-react';

interface ReportsProps {
  vehicles: Vehicle[];
}

export const Reports: React.FC<ReportsProps> = ({ vehicles }) => {
  const [reportType, setReportType] = useState<'USAGE' | 'IMPACT' | 'MAINTENANCE'>('USAGE');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = () => {
    setIsGenerating(true);
    // Simulate generation delay
    setTimeout(() => {
        setIsGenerating(false);
        // In a real app, this would trigger a file download
        alert(`Report "${reportType}_REPORT_${new Date().toISOString().split('T')[0]}.pdf" has been generated and sent to your email.`);
    }, 1500);
  };

  return (
    <div className="flex-1 bg-slate-900 overflow-y-auto p-8">
       <div className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-2">Fleet Reports</h2>
        <p className="text-slate-400">Generate operational insights, incident logs, and maintenance schedules.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Configuration Panel */}
        <div className="lg:col-span-1 space-y-6">
            <div className="bg-slate-800 p-6 rounded-xl border border-slate-700">
                <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <Filter className="w-5 h-5 text-sky-500" />
                    Report Configuration
                </h3>

                <div className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-400 mb-2">Report Type</label>
                        <div className="grid grid-cols-1 gap-2">
                            <button 
                                onClick={() => setReportType('USAGE')}
                                className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${reportType === 'USAGE' ? 'bg-sky-500/20 border-sky-500 text-white' : 'bg-slate-700/50 border-slate-600 text-slate-400 hover:bg-slate-700'}`}
                            >
                                <Clock className="w-5 h-5" />
                                <div className="text-left">
                                    <div className="font-semibold text-sm">Engine Usage</div>
                                    <div className="text-xs opacity-70">Hours & Fuel Logs</div>
                                </div>
                            </button>
                            <button 
                                onClick={() => setReportType('IMPACT')}
                                className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${reportType === 'IMPACT' ? 'bg-red-500/20 border-red-500 text-white' : 'bg-slate-700/50 border-slate-600 text-slate-400 hover:bg-slate-700'}`}
                            >
                                <AlertTriangle className="w-5 h-5" />
                                <div className="text-left">
                                    <div className="font-semibold text-sm">Impact & Incidents</div>
                                    <div className="text-xs opacity-70">G-Force Alert Logs</div>
                                </div>
                            </button>
                            <button 
                                onClick={() => setReportType('MAINTENANCE')}
                                className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${reportType === 'MAINTENANCE' ? 'bg-amber-500/20 border-amber-500 text-white' : 'bg-slate-700/50 border-slate-600 text-slate-400 hover:bg-slate-700'}`}
                            >
                                <BarChart3 className="w-5 h-5" />
                                <div className="text-left">
                                    <div className="font-semibold text-sm">Maintenance Status</div>
                                    <div className="text-xs opacity-70">Service Schedules</div>
                                </div>
                            </button>
                        </div>
                    </div>

                    <div>
                         <label className="block text-sm font-medium text-slate-400 mb-2">Date Range</label>
                         <select className="w-full bg-slate-900 border border-slate-600 rounded-lg p-2.5 text-slate-200 focus:border-sky-500 focus:outline-none">
                             <option>Last 24 Hours</option>
                             <option>Last 7 Days</option>
                             <option>Last 30 Days</option>
                             <option>This Month</option>
                             <option>Custom Range</option>
                         </select>
                    </div>

                    <div>
                         <label className="block text-sm font-medium text-slate-400 mb-2">Format</label>
                         <div className="flex gap-4">
                             <label className="flex items-center gap-2 cursor-pointer">
                                 <input type="radio" name="format" defaultChecked className="text-sky-500 focus:ring-sky-500 bg-slate-900 border-slate-600"/>
                                 <span className="text-sm text-slate-300">PDF Document</span>
                             </label>
                             <label className="flex items-center gap-2 cursor-pointer">
                                 <input type="radio" name="format" className="text-sky-500 focus:ring-sky-500 bg-slate-900 border-slate-600"/>
                                 <span className="text-sm text-slate-300">CSV Export</span>
                             </label>
                         </div>
                    </div>

                    <button 
                        onClick={handleGenerate}
                        disabled={isGenerating}
                        className="w-full mt-4 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
                    >
                        {isGenerating ? (
                            <>Processing...</>
                        ) : (
                            <>
                                <Download className="w-5 h-5" />
                                Generate Report
                            </>
                        )}
                    </button>
                </div>
            </div>
        </div>

        {/* Preview Panel (Static Mock) */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-xl overflow-hidden flex flex-col min-h-[500px]">
            <div className="p-8 border-b border-gray-200">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">AeroTrack GSE Report</h1>
                        <p className="text-gray-500">Sydney Operations • Generated on {new Date().toLocaleDateString()}</p>
                    </div>
                    <div className="text-right">
                        <div className="text-sm font-bold text-gray-900 uppercase">Report ID</div>
                        <div className="text-gray-500 font-mono">RPT-{Math.floor(Math.random() * 10000)}</div>
                    </div>
                </div>

                <div className="prose max-w-none">
                    <p className="text-gray-600 mb-6">
                        This document contains the <strong className="text-gray-900">{reportType.toLowerCase()}</strong> summary for the requested period.
                        Data is aggregated from {vehicles.length} active units on the apron.
                    </p>

                    <table className="min-w-full divide-y divide-gray-300 border border-gray-200 rounded-lg">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Vehicle</th>
                                <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Type</th>
                                <th className="px-3 py-3.5 text-right text-sm font-semibold text-gray-900">
                                    {reportType === 'USAGE' ? 'Engine Hours' : (reportType === 'IMPACT' ? 'Max G-Force' : 'Next Service')}
                                </th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200 bg-white">
                            {vehicles.slice(0, 5).map(v => (
                                <tr key={v.id}>
                                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-900">{v.name}</td>
                                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{v.type}</td>
                                    <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500 text-right font-mono">
                                        {reportType === 'USAGE' ? `${v.telemetry.engineHours.toFixed(1)} h` : 
                                         (reportType === 'IMPACT' ? `${v.lastImpact?.gForce || 0}g` : '150 h')}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            <div className="bg-gray-50 p-4 text-center text-xs text-gray-400 mt-auto border-t border-gray-200">
                End of Report Preview • Page 1 of 1
            </div>
        </div>
      </div>
    </div>
  );
};