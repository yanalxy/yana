import React from 'react';
import { Vehicle } from '../types';
import { TabletSmartphone, Battery, Signal, Wifi, WifiOff, Calendar, AlertCircle } from 'lucide-react';

interface InventoryProps {
  vehicles: Vehicle[];
}

export const Inventory: React.FC<InventoryProps> = ({ vehicles }) => {
  return (
    <div className="flex-1 bg-slate-900 overflow-y-auto p-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-white mb-2">Device Inventory</h2>
        <p className="text-slate-400">Manage GPS tracking hardware, SIM cards, and connectivity status.</p>
      </div>

      <div className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden shadow-xl">
        <table className="w-full text-left">
          <thead className="bg-slate-900/50 text-slate-400 uppercase text-xs font-medium">
            <tr>
              <th className="px-6 py-4">Vehicle ID</th>
              <th className="px-6 py-4">Hardware Model</th>
              <th className="px-6 py-4">IMEI / Serial</th>
              <th className="px-6 py-4">SIM Number</th>
              <th className="px-6 py-4">Install Date</th>
              <th className="px-6 py-4">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700">
            {vehicles.map((vehicle) => (
              <tr key={vehicle.id} className="hover:bg-slate-750 transition-colors">
                <td className="px-6 py-4">
                  <div className="font-medium text-white">{vehicle.name}</div>
                  <div className="text-xs text-slate-500">{vehicle.id}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2 text-slate-300">
                    <TabletSmartphone className="w-4 h-4 text-slate-500" />
                    {vehicle.device.model}
                  </div>
                </td>
                <td className="px-6 py-4 font-mono text-sm text-slate-400">
                  {vehicle.device.imei}
                </td>
                <td className="px-6 py-4 text-slate-300">
                  {vehicle.device.simNumber}
                </td>
                <td className="px-6 py-4 text-slate-400 text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3 h-3" />
                    {vehicle.device.installDate}
                  </div>
                </td>
                <td className="px-6 py-4">
                  {vehicle.device.status === 'ONLINE' && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                      <Wifi className="w-3 h-3" /> Online
                    </span>
                  )}
                  {vehicle.device.status === 'OFFLINE' && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-500/10 text-slate-400 border border-slate-500/20">
                      <WifiOff className="w-3 h-3" /> Offline
                    </span>
                  )}
                  {vehicle.device.status === 'MAINTENANCE' && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20">
                      <AlertCircle className="w-3 h-3" /> Maint.
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
        <div className="p-4 bg-slate-800 rounded-lg border border-slate-700">
            <div className="text-slate-400 text-sm mb-1">Total Devices</div>
            <div className="text-2xl font-bold text-white">{vehicles.length}</div>
        </div>
        <div className="p-4 bg-slate-800 rounded-lg border border-slate-700">
            <div className="text-slate-400 text-sm mb-1">Active SIM Cards</div>
            <div className="text-2xl font-bold text-sky-400">{vehicles.length}</div>
        </div>
        <div className="p-4 bg-slate-800 rounded-lg border border-slate-700">
            <div className="text-slate-400 text-sm mb-1">Hardware Health</div>
            <div className="text-2xl font-bold text-emerald-400">98%</div>
        </div>
      </div>
    </div>
  );
};