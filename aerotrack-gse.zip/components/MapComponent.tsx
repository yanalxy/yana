import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Vehicle } from '../types';
import { AIRPORT_CENTER } from '../constants';
import { Maximize, Focus } from 'lucide-react';

// Fix for default Leaflet marker icons in React
const iconPerson = new L.Icon({
    iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
    iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
    shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
});

// Custom markers using DivIcon for rotation and status color
const createVehicleIcon = (vehicle: Vehicle, isSelected: boolean) => {
    const color = vehicle.lastImpact ? '#ef4444' : (vehicle.telemetry.accStatus ? '#10b981' : '#64748b');
    const size = isSelected ? 36 : 28;
    
    // Increased shadow opacity for better visibility on light map
    return L.divIcon({
        className: 'custom-vehicle-marker',
        html: `
            <div style="
                background-color: ${color};
                width: ${size}px;
                height: ${size}px;
                border-radius: 50%;
                border: 2px solid white;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 3px 8px rgba(0, 0, 0, 0.5); 
                transition: all 0.3s ease;
                position: relative;
            ">
                <div style="
                    transform: rotate(${vehicle.heading}deg);
                    width: 0; 
                    height: 0; 
                    border-left: 5px solid transparent;
                    border-right: 5px solid transparent;
                    border-bottom: 8px solid white;
                "></div>
                ${vehicle.telemetry.strobeLight ? `<div style="position:absolute; width:100%; height:100%; border-radius:50%; border: 2px solid #fbbf24; animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>` : ''}
            </div>
            <style>
                @keyframes ping {
                    75%, 100% { transform: scale(1.5); opacity: 0; }
                }
            </style>
        `,
        iconSize: [size, size],
        iconAnchor: [size / 2, size / 2]
    });
};

interface MapComponentProps {
    vehicles: Vehicle[];
    selectedVehicleId: string | null;
    onSelectVehicle: (id: string) => void;
}

const MapUpdater: React.FC<{ center: [number, number], zoom: number, vehicles: Vehicle[] }> = ({ center, zoom, vehicles }) => {
    const map = useMap();
    
    useEffect(() => {
        // Manual control or vehicle selection updates view
        map.flyTo(center, zoom);
    }, [center, zoom, map]);

    return null;
}

// Button to fit all vehicles
const FitBoundsControl: React.FC<{ vehicles: Vehicle[] }> = ({ vehicles }) => {
    const map = useMap();
    const handleFitBounds = () => {
        if (vehicles.length === 0) return;
        const bounds = L.latLngBounds(vehicles.map(v => [v.lat, v.lng]));
        map.flyToBounds(bounds, { padding: [50, 50], maxZoom: 18 });
    };

    return (
        <div className="leaflet-top leaflet-right" style={{ pointerEvents: 'none' }}>
            <div className="leaflet-control leaflet-bar" style={{ pointerEvents: 'auto', marginTop: '80px', marginRight: '10px', border: 'none', boxShadow: '0 2px 5px rgba(0,0,0,0.3)' }}>
                <button 
                    onClick={handleFitBounds}
                    className="bg-white hover:bg-gray-100 text-gray-700 w-9 h-9 flex items-center justify-center cursor-pointer border-b border-gray-300 last:border-0"
                    title="Fit All Vehicles"
                >
                    <Maximize className="w-5 h-5" />
                </button>
            </div>
        </div>
    );
};

export const MapComponent: React.FC<MapComponentProps> = ({ vehicles, selectedVehicleId, onSelectVehicle }) => {
    const selectedVehicle = vehicles.find(v => v.id === selectedVehicleId);
    
    // Default view
    let center: [number, number] = AIRPORT_CENTER as [number, number];
    let zoom = 15;

    if (selectedVehicle) {
        center = [selectedVehicle.lat, selectedVehicle.lng];
        zoom = 18;
    }

    return (
        <MapContainer 
            center={AIRPORT_CENTER as [number, number]} 
            zoom={15} 
            style={{ height: "100%", width: "100%", zIndex: 0 }}
            className="bg-gray-100"
            zoomControl={true}
        >
            <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            <MapUpdater center={center} zoom={zoom} vehicles={vehicles} />
            <FitBoundsControl vehicles={vehicles} />

            {vehicles.map(vehicle => (
                <Marker 
                    key={vehicle.id} 
                    position={[vehicle.lat, vehicle.lng]}
                    icon={createVehicleIcon(vehicle, vehicle.id === selectedVehicleId)}
                    eventHandlers={{
                        click: () => onSelectVehicle(vehicle.id)
                    }}
                >
                    <Popup className="custom-popup">
                        <div className="text-slate-800">
                            <strong>{vehicle.name}</strong><br/>
                            Status: {vehicle.telemetry.accStatus ? 'Running' : 'Parked'}
                        </div>
                    </Popup>
                </Marker>
            ))}
        </MapContainer>
    );
};