import React from 'react';
import { Vehicle, VehicleType } from '../types';
import { Car, Truck, Plane, Zap, AlertTriangle, Key } from 'lucide-react';

interface VehicleCardProps {
  vehicle: Vehicle;
  isSelected: boolean;
  onClick: () => void;
}

export const VehicleCard: React.FC<VehicleCardProps> = ({ vehicle, isSelected, onClick }) => {
  const getIcon = () => {
    switch (vehicle.type) {
      case VehicleType.TUG: return <Truck className="w-5 h-5" />;
      case VehicleType.SHUTTLE: return <Car className="w-5 h-5" />;
      case VehicleType.BELT_LOADER: return <div className="font-bold text-xs border border-current px-1 rounded">BL</div>;
      default: return <Truck className="w-5 h-5" />;
    }
  };

  const isMoving = vehicle.telemetry.speed > 0;
  const hasAlert = vehicle.lastImpact && (Date.now() - vehicle.lastImpact.timestamp) < 3600000; // Alert within last hour

  return (
    <div 
      onClick={onClick}
      className={`
        p-4 border-b border-slate-700 cursor-pointer transition-colors duration-200
        ${isSelected ? 'bg-slate-700 border-l-4 border-l-sky-500' : 'bg-slate-800 hover:bg-slate-750 border-l-4 border-l-transparent'}
      `}
    >
      <div className="flex justify-between items-start">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded-lg ${vehicle.telemetry.accStatus ? 'bg-sky-500/20 text-sky-400' : 'bg-slate-600/20 text-slate-400'}`}>
            {getIcon()}
          </div>
          <div>
            <h3 className="text-slate-100 font-semibold text-sm">{vehicle.name}</h3>
            <p className="text-slate-400 text-xs">{vehicle.id}</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
           {hasAlert && <AlertTriangle className="w-4 h-4 text-red-500 animate-pulse" />}
           {!hasAlert && vehicle.telemetry.accStatus && <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>}
           {!hasAlert && !vehicle.telemetry.accStatus && <div className="w-2 h-2 rounded-full bg-slate-500"></div>}
        </div>
      </div>

      <div className="flex justify-between mt-3 text-xs text-slate-400">
        <div className="flex items-center gap-1">
            <Key className="w-3 h-3" />
            <span className={vehicle.telemetry.accStatus ? 'text-green-400' : ''}>{vehicle.telemetry.accStatus ? 'ACC ON' : 'ACC OFF'}</span>
        </div>
        <div className="flex items-center gap-1">
            <span>{vehicle.telemetry.engineHours.toFixed(1)}h</span>
        </div>
      </div>
    </div>
  );
};