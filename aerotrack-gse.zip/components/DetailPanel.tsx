import React, { useState } from 'react';
import { Vehicle } from '../types';
import { analyzeVehicleIncident, getMaintenanceAdvice } from '../services/geminiService';
import { 
  Gauge, 
  Clock, 
  Zap, 
  AlertTriangle, 
  Siren, 
  Activity, 
  Bot, 
  Loader2,
  Wrench,
  Smartphone,
  Send
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

interface DetailPanelProps {
  vehicle: Vehicle;
  onTriggerAlert?: () => void;
}

export const DetailPanel: React.FC<DetailPanelProps> = ({ vehicle, onTriggerAlert }) => {
  const [aiAnalysis, setAiAnalysis] = useState<{analysis: string, recommendation: string} | null>(null);
  const [maintenanceAdvice, setMaintenanceAdvice] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'status' | 'maintenance' | 'device'>('status');

  const handleAiAnalysis = async () => {
    setIsLoading(true);
    try {
      if (vehicle.lastImpact) {
        const result = await analyzeVehicleIncident(vehicle);
        setAiAnalysis(result);
      } else {
        const advice = await getMaintenanceAdvice(vehicle);
        setMaintenanceAdvice(advice);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const gForceData = [
    { name: 'X', value: vehicle.telemetry.gForceX },
    { name: 'Y', value: vehicle.telemetry.gForceY },
    { name: 'Z', value: vehicle.telemetry.gForceZ },
  ];

  return (
    <div className="h-full bg-slate-900 border-l border-slate-700 overflow-y-auto flex flex-col">
      {/* Header */}
      <div className="p-6 bg-slate-800 border-b border-slate-700">
        <h2 className="text-2xl font-bold text-white mb-1">{vehicle.name}</h2>
        <div className="flex items-center gap-2 text-slate-400 text-sm">
          <span className="bg-slate-700 px-2 py-0.5 rounded text-white">{vehicle.id}</span>
          <span>{vehicle.type}</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-700">
        <button 
          onClick={() => setActiveTab('status')}
          className={`flex-1 py-3 text-sm font-medium ${activeTab === 'status' ? 'text-sky-400 border-b-2 border-sky-400 bg-slate-800' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Status
        </button>
        <button 
          onClick={() => setActiveTab('maintenance')}
          className={`flex-1 py-3 text-sm font-medium ${activeTab === 'maintenance' ? 'text-sky-400 border-b-2 border-sky-400 bg-slate-800' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Maint.
        </button>
        <button 
          onClick={() => setActiveTab('device')}
          className={`flex-1 py-3 text-sm font-medium ${activeTab === 'device' ? 'text-sky-400 border-b-2 border-sky-400 bg-slate-800' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Device
        </button>
      </div>

      <div className="p-6 space-y-6 flex-1">
        
        {activeTab === 'status' && (
          <>
            {/* Primary Gauges */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
                <div className="flex items-center gap-2 text-slate-400 mb-2">
                  <Clock className="w-4 h-4" />
                  <span className="text-xs uppercase tracking-wider">Engine Hrs</span>
                </div>
                <div className="text-2xl font-mono text-white">
                  {vehicle.telemetry.engineHours.toLocaleString()} <span className="text-sm text-slate-500">h</span>
                </div>
                <div className="text-xs text-green-400 mt-1 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                  ACC ON
                </div>
              </div>

              <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
                <div className="flex items-center gap-2 text-slate-400 mb-2">
                  <Zap className="w-4 h-4" />
                  <span className="text-xs uppercase tracking-wider">Voltage</span>
                </div>
                <div className="text-2xl font-mono text-white">
                  {vehicle.telemetry.batteryVoltage} <span className="text-sm text-slate-500">V</span>
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  DC 24V
                </div>
              </div>
            </div>

            {/* Status Indicators */}
            <div className="grid grid-cols-2 gap-4">
              <div className={`p-4 rounded-xl border flex items-center gap-3 ${vehicle.telemetry.accStatus ? 'bg-sky-500/10 border-sky-500/50 text-sky-400' : 'bg-slate-800 border-slate-700 text-slate-500'}`}>
                <div className="p-2 rounded-full border border-current">
                   <Gauge className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs uppercase opacity-70">Ignition</div>
                  <div className="font-bold">{vehicle.telemetry.accStatus ? 'ACC ON' : 'ACC OFF'}</div>
                </div>
              </div>

              <div className={`p-4 rounded-xl border flex items-center gap-3 ${vehicle.telemetry.strobeLight ? 'bg-amber-500/10 border-amber-500/50 text-amber-400' : 'bg-slate-800 border-slate-700 text-slate-500'}`}>
                <div className="p-2 rounded-full border border-current">
                   <Siren className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs uppercase opacity-70">Strobe</div>
                  <div className="font-bold">{vehicle.telemetry.strobeLight ? 'ACTIVE' : 'INACTIVE'}</div>
                </div>
              </div>
            </div>

            {/* Impact Sensor Section */}
            <div className="bg-slate-800 rounded-xl border border-slate-700 p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-slate-300 font-medium">
                  <Activity className="w-4 h-4" />
                  G-Sensor (Impact)
                </div>
                {vehicle.lastImpact && (
                  <span className="text-xs bg-red-500/20 text-red-400 px-2 py-1 rounded border border-red-500/50">
                    IMPACT LOGGED
                  </span>
                )}
              </div>
              
              <div className="h-40 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={gForceData}>
                    <XAxis dataKey="name" stroke="#64748b" tick={{fill: '#94a3b8', fontSize: 12}} />
                    <YAxis stroke="#64748b" tick={{fill: '#94a3b8', fontSize: 12}} domain={[0, 4]} />
                    <Tooltip 
                      contentStyle={{backgroundColor: '#1e293b', borderColor: '#334155', color: '#f1f5f9'}}
                      itemStyle={{color: '#38bdf8'}}
                    />
                    <Bar dataKey="value" fill="#38bdf8" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Manual Alert Trigger */}
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
                 <h4 className="text-red-400 font-bold text-sm mb-2 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" /> Emergency Controls
                 </h4>
                 <p className="text-xs text-slate-400 mb-3">Simulate a high-impact event to test the SMS/Email gateway.</p>
                 <button 
                    onClick={onTriggerAlert}
                    className="w-full py-2 bg-red-600 hover:bg-red-500 text-white rounded text-sm font-bold flex items-center justify-center gap-2 transition-colors"
                 >
                    <Send className="w-4 h-4" />
                    Test Alert System
                 </button>
            </div>
          </>
        )}

        {activeTab === 'maintenance' && (
          <div className="space-y-4">
             <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
               <h3 className="text-slate-300 font-medium flex items-center gap-2 mb-3">
                 <Wrench className="w-4 h-4 text-sky-400" /> Maintenance Logs
               </h3>
               <ul className="space-y-3">
                 <li className="flex justify-between text-sm">
                   <span className="text-slate-400">Last Service</span>
                   <span className="text-white">350 Engine Hrs ago</span>
                 </li>
                 <li className="flex justify-between text-sm">
                   <span className="text-slate-400">Next Due</span>
                   <span className="text-white">In 150 Hrs</span>
                 </li>
                 <li className="flex justify-between text-sm">
                   <span className="text-slate-400">Status</span>
                   <span className={vehicle.maintenanceDue ? "text-red-400 font-bold" : "text-green-400"}>
                     {vehicle.maintenanceDue ? "DUE NOW" : "Good"}
                   </span>
                 </li>
               </ul>
             </div>

             {/* AI Section */}
             <div className="bg-gradient-to-br from-indigo-900/30 to-purple-900/30 p-4 rounded-xl border border-indigo-500/30">
               <div className="flex items-center gap-2 text-indigo-300 font-medium mb-3">
                 <Bot className="w-5 h-5" />
                 Gemini Fleet Assistant
               </div>
               
               <p className="text-xs text-slate-400 mb-4">
                 Use AI to analyze engine hours vs. usage patterns or investigate impact alerts.
               </p>

               {!aiAnalysis && !maintenanceAdvice && (
                 <button 
                  onClick={handleAiAnalysis}
                  disabled={isLoading}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-medium transition-colors flex justify-center items-center gap-2"
                >
                  {isLoading ? <Loader2 className="w-4 h-4 animate-spin"/> : <Zap className="w-4 h-4" />}
                  {vehicle.lastImpact ? 'Analyze Impact Data' : 'Check Maintenance Health'}
                 </button>
               )}

               {aiAnalysis && (
                  <div className="mt-4 space-y-3 animate-in fade-in slide-in-from-bottom-2">
                    <div className="bg-slate-900/50 p-3 rounded border border-indigo-500/20">
                      <div className="text-xs uppercase text-indigo-400 font-bold mb-1">Analysis</div>
                      <p className="text-sm text-slate-200">{aiAnalysis.analysis}</p>
                    </div>
                    <div className="bg-slate-900/50 p-3 rounded border border-green-500/20">
                      <div className="text-xs uppercase text-green-400 font-bold mb-1">Recommendation</div>
                      <p className="text-sm text-slate-200">{aiAnalysis.recommendation}</p>
                    </div>
                    <button 
                      onClick={() => setAiAnalysis(null)}
                      className="text-xs text-indigo-400 hover:text-indigo-300 underline"
                    >
                      Clear Analysis
                    </button>
                  </div>
               )}

               {maintenanceAdvice && (
                 <div className="mt-4 animate-in fade-in slide-in-from-bottom-2">
                    <div className="bg-slate-900/50 p-3 rounded border border-indigo-500/20">
                      <div className="text-xs uppercase text-indigo-400 font-bold mb-1">Fleet Advisor</div>
                      <p className="text-sm text-slate-200">{maintenanceAdvice}</p>
                    </div>
                    <button 
                      onClick={() => setMaintenanceAdvice(null)}
                      className="text-xs text-indigo-400 hover:text-indigo-300 underline mt-2"
                    >
                      Close
                    </button>
                 </div>
               )}

             </div>
          </div>
        )}

        {activeTab === 'device' && (
             <div className="space-y-4">
                 <div className="bg-slate-800 p-4 rounded-xl border border-slate-700">
                     <h3 className="text-slate-300 font-medium flex items-center gap-2 mb-3">
                         <Smartphone className="w-4 h-4 text-sky-400" /> Hardware Info
                     </h3>
                     <div className="space-y-3">
                         <div>
                             <label className="text-xs text-slate-500 uppercase">Device Model</label>
                             <div className="text-white text-sm">{vehicle.device.model}</div>
                         </div>
                         <div>
                             <label className="text-xs text-slate-500 uppercase">IMEI / Serial</label>
                             <div className="text-white text-sm font-mono bg-slate-900 p-2 rounded border border-slate-700">
                                 {vehicle.device.imei}
                             </div>
                         </div>
                         <div>
                             <label className="text-xs text-slate-500 uppercase">SIM Number</label>
                             <div className="text-white text-sm">{vehicle.device.simNumber}</div>
                         </div>
                         <div>
                             <label className="text-xs text-slate-500 uppercase">Install Date</label>
                             <div className="text-white text-sm">{vehicle.device.installDate}</div>
                         </div>
                     </div>
                 </div>
             </div>
        )}

      </div>
    </div>
  );
};