import React, { useState, useEffect } from 'react';
import { MOCK_VEHICLES } from './constants';
import { Vehicle, AppView } from './types';
import { MapComponent } from './components/MapComponent';
import { VehicleCard } from './components/VehicleCard';
import { DetailPanel } from './components/DetailPanel';
import { Login } from './components/Login';
import { Inventory } from './components/Inventory';
import { Reports } from './components/Reports';
import { LayoutDashboard, ListFilter, Menu, X, LogOut, Package, FileBarChart, Bell } from 'lucide-react';

const App: React.FC = () => {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const [vehicles, setVehicles] = useState<Vehicle[]>(MOCK_VEHICLES);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [filter, setFilter] = useState<'ALL' | 'RUNNING' | 'ALERT'>('ALL');
  const [currentView, setCurrentView] = useState<AppView>('DASHBOARD');
  
  // Simulated Notification State
  const [notification, setNotification] = useState<{message: string, type: 'info' | 'error'} | null>(null);

  // Simulation effect: Updates engine hours and slight position changes
  useEffect(() => {
    if (!isAuthenticated) return;

    const interval = setInterval(() => {
      setVehicles(currentVehicles => 
        currentVehicles.map(v => {
          if (!v.telemetry.accStatus) return v;
          
          // Simulate movement if engine is on
          const moveFactor = 0.0001;
          const newLat = v.lat + (Math.random() - 0.5) * moveFactor;
          const newLng = v.lng + (Math.random() - 0.5) * moveFactor;

          // Add engine hours (simulated faster than real time for demo)
          const newEngineHours = v.telemetry.engineHours + 0.01;

          return {
            ...v,
            lat: newLat,
            lng: newLng,
            telemetry: {
              ...v.telemetry,
              engineHours: newEngineHours,
              // Randomly toggle strobe for variety if moving
              speed: Math.floor(Math.random() * 20) + 5
            }
          };
        })
      );
    }, 2000);

    return () => clearInterval(interval);
  }, [isAuthenticated]);

  // Clear notification after 5s
  useEffect(() => {
    if(notification) {
      const timer = setTimeout(() => setNotification(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const triggerManualAlert = (vehicleName: string) => {
    setNotification({
      message: `ALERT SENT: High Impact detected on ${vehicleName}. SMS & Email dispatched to Admin.`,
      type: 'error'
    });
  };

  const filteredVehicles = vehicles.filter(v => {
    if (filter === 'RUNNING') return v.telemetry.accStatus;
    if (filter === 'ALERT') return v.lastImpact || v.maintenanceDue;
    return true;
  });

  const selectedVehicle = vehicles.find(v => v.id === selectedVehicleId);

  // Show Login screen if not authenticated
  if (!isAuthenticated) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="flex h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      
      {/* Toast Notification */}
      {notification && (
        <div className={`fixed top-4 right-4 z-[100] p-4 rounded-lg shadow-2xl flex items-center gap-3 animate-in fade-in slide-in-from-top-4 ${notification.type === 'error' ? 'bg-red-600 text-white' : 'bg-sky-600 text-white'}`}>
           <Bell className="w-6 h-6 animate-bounce" />
           <div className="text-sm font-semibold">{notification.message}</div>
           <button onClick={() => setNotification(null)} className="ml-2 hover:bg-white/20 p-1 rounded"><X className="w-4 h-4"/></button>
        </div>
      )}

      {/* Mobile Sidebar Toggle */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <button 
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="p-2 bg-slate-800 rounded-md shadow-lg border border-slate-700"
        >
          {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Sidebar - Navigation & Vehicle List */}
      <div className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 transition-transform duration-300 absolute md:relative z-40 w-80 h-full bg-slate-900 border-r border-slate-800 flex flex-col shadow-2xl md:shadow-none`}>
        <div className="p-4 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setCurrentView('DASHBOARD')}>
              <LayoutDashboard className="w-6 h-6 text-sky-500" />
              <h1 className="text-xl font-bold tracking-tight">AeroTrack <span className="text-sky-500">GSE</span></h1>
            </div>
          </div>
          
          {/* Main Navigation */}
          <nav className="flex gap-1 mb-6 bg-slate-800 p-1 rounded-lg">
             <button 
                onClick={() => setCurrentView('DASHBOARD')}
                className={`flex-1 flex items-center justify-center p-2 rounded-md transition-all ${currentView === 'DASHBOARD' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-700'}`}
                title="Dashboard"
             >
               <LayoutDashboard className="w-5 h-5" />
             </button>
             <button 
                onClick={() => setCurrentView('INVENTORY')}
                className={`flex-1 flex items-center justify-center p-2 rounded-md transition-all ${currentView === 'INVENTORY' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-700'}`}
                title="Inventory"
             >
               <Package className="w-5 h-5" />
             </button>
             <button 
                onClick={() => setCurrentView('REPORTS')}
                className={`flex-1 flex items-center justify-center p-2 rounded-md transition-all ${currentView === 'REPORTS' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-white hover:bg-slate-700'}`}
                title="Reports"
             >
               <FileBarChart className="w-5 h-5" />
             </button>
          </nav>

          {/* Filters (Only visible in Dashboard view) */}
          {currentView === 'DASHBOARD' && (
            <div className="flex gap-2 p-1 bg-slate-800 rounded-lg">
               {['ALL', 'RUNNING', 'ALERT'].map((f) => (
                 <button
                  key={f}
                  onClick={() => setFilter(f as any)}
                  className={`flex-1 text-[10px] font-bold py-1.5 rounded-md transition-all ${filter === f ? 'bg-sky-600 text-white shadow' : 'text-slate-400 hover:text-white'}`}
                 >
                   {f}
                 </button>
               ))}
            </div>
          )}
        </div>

        {/* Sidebar Content Area */}
        <div className="flex-1 overflow-y-auto">
          {currentView === 'DASHBOARD' ? (
            <>
              {filteredVehicles.map(vehicle => (
                <VehicleCard 
                  key={vehicle.id} 
                  vehicle={vehicle} 
                  isSelected={selectedVehicleId === vehicle.id}
                  onClick={() => setSelectedVehicleId(vehicle.id)}
                />
              ))}
              {filteredVehicles.length === 0 && (
                 <div className="p-8 text-center text-slate-500 text-sm">
                   No vehicles match this filter.
                 </div>
              )}
            </>
          ) : (
            <div className="p-4 text-slate-500 text-sm text-center">
              Select a vehicle on the dashboard map to see details.
            </div>
          )}
        </div>
        
        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900">
           <button 
              onClick={() => setIsAuthenticated(false)}
              className="w-full flex items-center justify-center gap-2 p-2 rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition-colors text-sm"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col relative h-full">
        {currentView === 'DASHBOARD' && (
             <div className="flex-1 relative">
                <MapComponent 
                    vehicles={vehicles} 
                    selectedVehicleId={selectedVehicleId}
                    onSelectVehicle={setSelectedVehicleId}
                />
             </div>
        )}
        {currentView === 'INVENTORY' && <Inventory vehicles={vehicles} />}
        {currentView === 'REPORTS' && <Reports vehicles={vehicles} />}
      </div>

      {/* Right Panel - Vehicle Details (Dashboard Only) */}
      {selectedVehicle && currentView === 'DASHBOARD' && (
        <div className="w-96 border-l border-slate-800 h-full absolute right-0 top-0 z-30 shadow-2xl md:relative md:shadow-none bg-slate-900 transition-all">
           <button 
             onClick={() => setSelectedVehicleId(null)}
             className="absolute top-2 right-2 md:hidden p-2 bg-slate-800 rounded-full z-50 text-white"
           >
             <X className="w-5 h-5" />
           </button>
           <DetailPanel vehicle={selectedVehicle} onTriggerAlert={() => triggerManualAlert(selectedVehicle.name)} />
        </div>
      )}

    </div>
  );
};

export default App;