import { GoogleGenAI, Type } from "@google/genai";
import { Vehicle } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeVehicleIncident = async (vehicle: Vehicle): Promise<{ analysis: string, recommendation: string }> => {
  try {
    const prompt = `
      You are an expert Airport Ground Support Equipment (GSE) safety analyst.
      Analyze the following telemetry data for a vehicle that triggered an alert.
      
      Vehicle: ${vehicle.name} (${vehicle.type})
      ID: ${vehicle.id}
      Engine Hours: ${vehicle.telemetry.engineHours}
      Battery Voltage: ${vehicle.telemetry.batteryVoltage}V
      Recorded Impact G-Force: ${vehicle.lastImpact ? vehicle.lastImpact.gForce + 'g' : 'N/A'}
      Ignition Status: ${vehicle.telemetry.accStatus ? 'ON' : 'OFF'}
      Speed at time of query: ${vehicle.telemetry.speed} km/h
      
      Context: 
      - Airport vehicles must operate under strict safety rules.
      - Impact detection > 2.5g usually indicates a collision with infrastructure or aircraft.
      - Engine hours are critical for maintenance cycles.
      
      Provide a concise safety analysis and a specific maintenance recommendation.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: { type: Type.STRING, description: "Detailed analysis of the incident or state." },
            recommendation: { type: Type.STRING, description: "Actionable steps for the fleet manager." }
          },
          required: ["analysis", "recommendation"]
        }
      }
    });

    const json = JSON.parse(response.text || '{}');
    return json;
  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    return {
      analysis: "Unable to contact AI analysis service.",
      recommendation: "Perform manual inspection immediately."
    };
  }
};

export const getMaintenanceAdvice = async (vehicle: Vehicle): Promise<string> => {
   try {
    const prompt = `
      Vehicle: ${vehicle.name} (${vehicle.type})
      Engine Hours: ${vehicle.telemetry.engineHours}
      Current Voltage: ${vehicle.telemetry.batteryVoltage}V
      
      Based on typical airport GSE maintenance schedules (usually every 250 or 500 hours), provide a very short maintenance status summary (1-2 sentences).
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });

    return response.text || "Maintenance data unavailable.";
   } catch (error) {
     return "AI Service Unavailable.";
   }
}