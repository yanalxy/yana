import { Vehicle, VehicleType } from './types';

// Sydney Kingsford Smith Airport (SYD)
export const AIRPORT_CENTER = [-33.9399, 151.1753]; 

export const MOCK_VEHICLES: Vehicle[] = [
  {
    id: 'GSE-001',
    name: 'Pushback Tug 01',
    type: VehicleType.TUG,
    // Near Terminal 1 International
    lat: -33.9360,
    lng: 151.1730,
    heading: 45,
    maintenanceDue: false,
    device: {
      imei: '864200123456789',
      simNumber: '+61 400 123 456',
      model: 'ST-901 Hardwired',
      installDate: '2023-01-15',
      status: 'ONLINE',
      lastPing: Date.now()
    },
    telemetry: {
      timestamp: Date.now(),
      accStatus: true,
      engineHours: 4120.5,
      batteryVoltage: 26.4,
      strobeLight: true,
      speed: 12,
      gForceX: 0.1,
      gForceY: 0.05,
      gForceZ: 0.98,
      fuelLevel: 78
    }
  },
  {
    id: 'GSE-004',
    name: 'Belt Loader 12',
    type: VehicleType.BELT_LOADER,
    // Domestic Terminals area
    lat: -33.9320,
    lng: 151.1820,
    heading: 180,
    maintenanceDue: true,
    device: {
      imei: '864200987654321',
      simNumber: '+61 400 987 654',
      model: 'ST-906 Impact Pro',
      installDate: '2023-03-22',
      status: 'ONLINE',
      lastPing: Date.now()
    },
    telemetry: {
      timestamp: Date.now(),
      accStatus: false,
      engineHours: 12500.1,
      batteryVoltage: 23.8,
      strobeLight: false,
      speed: 0,
      gForceX: 0.0,
      gForceY: 0.0,
      gForceZ: 1.0,
      fuelLevel: 45
    }
  },
  {
    id: 'GSE-007',
    name: 'Apron Bus 03',
    type: VehicleType.SHUTTLE,
    // On a taxiway near cargo
    lat: -33.9450,
    lng: 151.1780,
    heading: 270,
    maintenanceDue: false,
    lastImpact: {
      timestamp: Date.now() - 1000 * 60 * 30, // 30 mins ago
      gForce: 3.5,
      description: "Sudden deceleration detected"
    },
    device: {
      imei: '864200456123789',
      simNumber: '+61 411 222 333',
      model: 'ST-905 WideVolt',
      installDate: '2023-06-10',
      status: 'MAINTENANCE',
      lastPing: Date.now() - 3600000
    },
    telemetry: {
      timestamp: Date.now(),
      accStatus: true,
      engineHours: 890.4,
      batteryVoltage: 13.8,
      strobeLight: true,
      speed: 25,
      gForceX: 0.2,
      gForceY: 0.1,
      gForceZ: 1.05,
      fuelLevel: 92
    }
  },
  {
    id: 'GSE-015',
    name: 'De-icer Alpha',
    type: VehicleType.DEICER,
    // Maintenance area
    lat: -33.9420,
    lng: 151.1700,
    heading: 0,
    maintenanceDue: false,
    device: {
      imei: '864200741852963',
      simNumber: '+61 499 888 777',
      model: 'ST-901 Hardwired',
      installDate: '2022-11-05',
      status: 'OFFLINE',
      lastPing: Date.now() - 86400000
    },
    telemetry: {
      timestamp: Date.now(),
      accStatus: false,
      engineHours: 320.0,
      batteryVoltage: 24.1,
      strobeLight: false,
      speed: 0,
      gForceX: 0.0,
      gForceY: 0.0,
      gForceZ: 1.0,
      fuelLevel: 100
    }
  }
];