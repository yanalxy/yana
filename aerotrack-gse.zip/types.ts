export enum VehicleType {
  TUG = 'Aircraft Tug',
  BELT_LOADER = 'Belt Loader',
  SHUTTLE = 'Apron Bus',
  DEICER = 'De-icing Truck',
  GPU = 'Ground Power Unit'
}

export enum AlertLevel {
  NONE = 'None',
  WARNING = 'Warning',
  CRITICAL = 'Critical'
}

export interface DeviceInfo {
  imei: string;
  simNumber: string;
  model: string;
  installDate: string;
  status: 'ONLINE' | 'OFFLINE' | 'MAINTENANCE';
  lastPing: number;
}

export interface Telemetry {
  timestamp: number;
  accStatus: boolean; // Ignition
  engineHours: number; // Cumulative hours
  batteryVoltage: number;
  strobeLight: boolean;
  speed: number;
  gForceX: number;
  gForceY: number;
  gForceZ: number;
  fuelLevel: number;
}

export interface Vehicle {
  id: string;
  name: string;
  type: VehicleType;
  lat: number;
  lng: number;
  heading: number;
  telemetry: Telemetry;
  device: DeviceInfo;
  lastImpact?: {
    timestamp: number;
    gForce: number;
    description: string;
  };
  maintenanceDue: boolean;
}

export interface AiAnalysisResult {
  analysis: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  recommendedActions: string[];
}

export type AppView = 'DASHBOARD' | 'INVENTORY' | 'REPORTS';